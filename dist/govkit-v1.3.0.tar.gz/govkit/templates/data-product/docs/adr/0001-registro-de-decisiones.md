# ADR-0001: Registrar las decisiones de arquitectura del Data Product

- Estado: aceptado
- Fecha: %%today%%

## Contexto
Toda decisión técnica significativa (formato, nueva fuente, migración de servicio) debe quedar documentada
(lineamiento Estructura de Repositorio · docs/adr).

## Decisión
Usar ADRs numerados (`NNNN-titulo.md`) con Contexto, Decisión y Consecuencias.

## Consecuencias
Las excepciones a reglas de gobierno deben referenciar un ADR (motivo, responsable y vencimiento).
